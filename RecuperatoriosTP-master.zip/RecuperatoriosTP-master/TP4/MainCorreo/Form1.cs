﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MainCorreo
{
    public partial class Form1 : Entidades.FrmPpal
    {
        public Form1()
        {
            InitializeComponent();
        }
    }
}
